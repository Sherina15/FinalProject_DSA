const body = document.querySelector("body");
const sidebar = body.querySelector(".sidebar"); 
const toggleBtn = body.querySelector(".sidebar header .toggle");
const searchBtn = body.querySelector(".search-box input"); 
const modeSwitch = body.querySelector(".toggle-switch");
const modeText = body.querySelector(".mode-text");


toggleBtn.addEventListener('click', () => {
    sidebar.classList.toggle('close');
});

searchBtn.addEventListener('click', () => {
    sidebar.classList.remove('close');
});