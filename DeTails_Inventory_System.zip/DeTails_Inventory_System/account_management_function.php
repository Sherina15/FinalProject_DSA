<?php
	session_start();

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "details_inventory_management";

	$connection = new mysqli($servername, $username, $password, $dbname);

	if($connection->connect_error)
	{
		die("Connection Failed: " . $connection->connect_error);
	}


	if(isset($_POST['save_data']))
	{
		$full_name = $_POST['full_name'];
		$username = $_POST['username'];
		$email = $_POST['email'];
		$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

		$check_query = "SELECT * FROM account_management WHERE username = '$username'OR email = '$email'";
		$result = $connection->query($check_query);

		if ($result->num_rows > 0) 
		{
			echo $_SESSION['status'] = "Username or Email already exist";
			header('Location: dashboard.php?page=account');
		}
		else
		{
			$insert_query = "INSERT INTO account_management (full_name, username, email, password) 
					         VALUES ('$full_name', '$username', '$email', '$password')";

			$insert_query_run = mysqli_query($connection, $insert_query);

			if ($insert_query_run)
			{
				$_SESSION['status'] = "Data added successfully.";
				header('Location: dashboard.php?page=account');
			}
			else
			{
				$_SESSION['status'] = "Data insertation failed.";
				header('Location: dashboard.php?page=account');
			}
		} 		
	}

	if(isset($_POST['click_view_btn']))
	{
		$id =$_POST['account_id'];
		
		$fetch_query = "SELECT * FROM account_management WHERE id ='$id'";
		$fetch_query_run = mysqli_query($connection, $fetch_query);

			if(mysqli_num_rows($fetch_query_run) > 0)
			{
				while($row = mysqli_fetch_array($fetch_query_run))
				{
					echo '
						<h6>ID: ' .$row['id']. '</h6>
						<h6>Full Name: ' .$row['full_name']. '</h6>
						<h6>Username: ' .$row['username']. '</h6>
						<h6>Email: ' .$row['email']. '</h6>
						';
				}
			}
			else
			{
				echo '<h4> No record found </h4>';
			}
	}

	if(isset($_POST['click_edit_btn']))
	{
		$id =$_POST['account_id'];
		$arrayResult =[];
		
		$fetch_query = "SELECT * FROM account_management WHERE id ='$id'";
		$fetch_query_run = mysqli_query($connection, $fetch_query);

			if(mysqli_num_rows($fetch_query_run) > 0)
			{
				while($row = mysqli_fetch_array($fetch_query_run))
				{
					array_push($arrayResult, $row);
					header('content-type: application/json');
					echo json_encode($arrayResult);
				}
			}
			else
			{					
				echo '<h4> No record found </h4>';
			}
	}

	if (isset($_POST['update_data'])) 
	{
	    $id = $_POST['id'];
	    $full_name = $_POST['full_name'];
	    $username = $_POST['username'];
	    $email = $_POST['email'];

	    $servername = "localhost";
	    $dbUsername = "root";
	    $password = "";
	    $dbname = "details_inventory_management";

	    $connection = new mysqli($servername, $dbUsername, $password, $dbname);

	    if ($connection->connect_error) 
	    {
	        die("Connection Failed: " . $connection->connect_error);
	    }

	    $check_query = "SELECT * FROM account_management WHERE username = '$username' AND id != '$id'";
	    $result = $connection->query($check_query);

	    if ($result->num_rows > 0) 
	    {
	       
	        $_SESSION['status'] = "Username already exists";
	        header('Location: dashboard.php?page=account');
	        exit; // Important to prevent further execution
	    } 
	    else 
	    {
	      
	        $update_query = "UPDATE account_management SET username = '$username', email = '$email' WHERE id = $id";

	        if ($connection->query($update_query) === TRUE) 
	        {
	            $_SESSION['status'] = "Data updated successfully.";
	            header('Location: dashboard.php?page=account');
	            exit; // Important to prevent further execution
	        } 
	        else 
	        {
	            $_SESSION['status'] = "Data update failed: " . $connection->error; 
	            header('Location: dashboard.php?page=account');
	            exit; 
	        }
	    }

	    $connection->close(); 
	}

?>