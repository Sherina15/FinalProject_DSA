<?php
	session_start();

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "details_inventory_management";

	$connection = new mysqli($servername, $username, $password, $dbname);

	if($connection->connect_error)
	{
		die("Connection Failed: " . $connection->connect_error);
	}

	if(isset($_POST['save_data']))
	{
		$product_name = $_POST['product_name'];
		$category = $_POST['category'];
		$quantity = $_POST['quantity'];
		$price = $_POST['price'];
		
			$insert_query = "INSERT INTO product_management (product_name, category, quantity, price) 
					         VALUES ('$product_name', '$category', '$quantity', '$price')";

			$insert_query_run = mysqli_query($connection, $insert_query);

			if ($insert_query_run)
			{
				$_SESSION['status'] = "Product added successfully.";
				header('Location: dashboard.php?page=product_list');
			}
			else
			{
				$_SESSION['status'] = "Product insertation failed.";
				header('Location: dashboard.php?page=product_list');
			}
	}

	if (isset($_POST['click_view_btn'])) 
	{
	    $id = $_POST['product_id'];

	    $fetch_query = "SELECT * FROM product_management WHERE id ='$id'";
	    $fetch_query_run = mysqli_query($connection, $fetch_query);

	    if (mysqli_num_rows($fetch_query_run) > 0) 
	    {
	        while ($row = mysqli_fetch_array($fetch_query_run)) 
	        {
	            echo '
	                <h6>ID: ' . htmlspecialchars($row['id']) . '</h6>
	                <h6>Product Name: ' . htmlspecialchars($row['product_name']) . '</h6>
	                <h6>Category: ' . htmlspecialchars($row['category']) . '</h6>
	                <h6>Quantity: ' . htmlspecialchars($row['quantity']) . '</h6>
	                <h6>Price: ' . htmlspecialchars($row['price']) . '</h6>
	                <h6>Date Added: ' . htmlspecialchars($row['date_added']) . '</h6>
	                <h6>Updated Date: ' . htmlspecialchars($row['updated_at']) . '</h6> <!-- Include Updated Date -->
	            ';
	        }
	    } else {
	        echo '<h4>No record found</h4>';
	    }
	}


	if(isset($_POST['click_edit_btn']))
	{
		$id =$_POST['product_id'];
		$arrayResult =[];
		
		$fetch_query = "SELECT * FROM product_management WHERE id ='$id'";
		$fetch_query_run = mysqli_query($connection, $fetch_query);

			if(mysqli_num_rows($fetch_query_run) > 0)
			{
				while($row = mysqli_fetch_array($fetch_query_run))
				{
					array_push($arrayResult, $row);
					header('content-type: application/json');
					echo json_encode($arrayResult);
				}
			}
			else
			{
				echo '<h4> No record found </h4>';
			}
	}




	if (isset($_POST['update_product'])) 
	{
	    $id = $_POST['id'];
	    $quantity = $_POST['quantity'];
	    $price = $_POST['price'];

	    $servername = "localhost";
	    $dbUsername = "root"; 
	    $password = "";
	    $dbname = "details_inventory_management";

	    $connection = new mysqli($servername, $dbUsername, $password, $dbname);

	    if ($connection->connect_error) 
	    {
	        die("Connection Failed: " . $connection->connect_error);
    	}

	    $update_query = "UPDATE product_management 
	                     SET quantity = '$quantity', price = '$price', updated_at = NOW() 
	                     WHERE id = $id";

	    if ($connection->query($update_query) === TRUE) 
	    {
	        $_SESSION['status'] = "Product updated successfully.";
	        header('Location: dashboard.php?page=product_list');
	        exit; // Important to prevent further execution
	    } 
	    else 
	    {
	        $_SESSION['status'] = "Product update failed: " . $connection->error; 
	        header('Location: dashboard.php?page=product_list');
	        exit; 
	    }

	    $connection->close(); 
	}

	if (isset($_POST['click_delete_btn'])) 
	{
	    $servername = "localhost";
	    $username = "root";
	    $password = "";
	    $dbname = "details_inventory_management";
	    
	    $connection = new mysqli($servername, $username, $password, $dbname);

	    if ($connection->connect_error) 
	    {
	        die("Connection failed: " . $connection->connect_error);
	    }

	    $id = $_POST['product_id'];

	    $delete_query = "DELETE FROM product_management WHERE id = '$id'";
	    

	    if ($connection->query($delete_query) === TRUE) {
	        $_SESSION['status'] = "Product deleted successfully.";
	        echo json_encode(['status' => 'success']);
	    } else {
	        $_SESSION['status'] = "Product deletion failed: " . $connection->error; 
	        echo json_encode(['status' => 'failed']);
	    }

	    $connection->close(); 
	}

?>
