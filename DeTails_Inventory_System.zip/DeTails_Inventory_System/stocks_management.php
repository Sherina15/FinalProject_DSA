<?php 
session_start();
if (!isset($_SESSION['username'])) 
{
    header('Location: login.php'); 
    exit();
}

$username = htmlspecialchars($_SESSION['username']);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "details_inventory_management";

$connection = new mysqli($servername, $username, $password, $dbname);

if ($connection->connect_error) {
    die("Connection Failed: " . $connection->connect_error);
}

function processPurchase($productName, $quantity) 
{
    global $connection;

    $check_product_query = "SELECT * FROM product_management WHERE product_name = ?";
    $check_stmt = $connection->prepare($check_product_query);
    $check_stmt->bind_param("s", $productName);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows === 0) 
    {
        echo "Product not found: " . htmlspecialchars($productName);
        return;
    }

    $product_query = "SELECT * FROM product_management WHERE product_name = ? AND quantity > 0 ORDER BY date_added ASC";
    $stmt = $connection->prepare($product_query);
    $stmt->bind_param("s", $productName);
    $stmt->execute();
    $result = $stmt->get_result();

    $total_available = 0;
    $products = [];

    while ($row = $result->fetch_assoc()) 
    {
        $total_available += $row['quantity'];
        $products[] = $row;
    }

    if ($total_available < $quantity) 
    {
        echo "Not enough stock available for product: " . htmlspecialchars($productName);
        return;
    }

    foreach ($products as $row) 
    {
        if ($quantity <= 0) 
        {
            break;
        }

        $available_quantity = $row['quantity'];
        $product_price = $row['price'];

        if ($available_quantity > 0) 
        {
            $deduct_quantity = min($available_quantity, $quantity);

            $new_quantity = $available_quantity - $deduct_quantity;
            $update_query = "UPDATE product_management SET quantity = ? WHERE id = ?";
            $update_stmt = $connection->prepare($update_query);
            $update_stmt->bind_param("ii", $new_quantity, $row['id']);
            $update_stmt->execute();

            $quantity -= $deduct_quantity;

            $insert_purchase_query = "INSERT INTO purchase_management (product_name, category, purchased_quantity, price, purchase_date) VALUES (?, ?, ?, ?, NOW())";
            $insert_purchase_stmt = $connection->prepare($insert_purchase_query);
            $insert_purchase_stmt->bind_param("ssdi", $row['product_name'], $row['category'], $deduct_quantity, $product_price);
            $insert_purchase_stmt->execute();

            if ($new_quantity == 0) 
            {
                $insert_history_query = "INSERT INTO purchase_history (product_name, category, quantity, price, date_added) VALUES (?, ?, ?, ?, ?)";
                $insert_stmt = $connection->prepare($insert_history_query);
                $insert_stmt->bind_param("ssids", $row['product_name'], $row['category'], $row['quantity'], $row['price'], $row['date_added']);
                $insert_stmt->execute();

                $delete_query = "DELETE FROM product_management WHERE id = ?";
                $delete_stmt = $connection->prepare($delete_query);
                $delete_stmt->bind_param("i", $row['id']);
                $delete_stmt->execute();
            }
        }
    }

    echo "Purchase successful for product: " . htmlspecialchars($productName);

    $stmt->close();
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    $productName = $_POST['product_name'];
    $quantity = (int)$_POST['quantity'];
    
    ob_start();
    processPurchase($productName, $quantity);
    $message = ob_get_clean();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body 
        {
            background-color: #f8f9fa;
            color: #343a40;
            font-family: 'Poppins', sans-serif;
        }

        .container 
        {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #000;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        h1 
        {
            font-weight: 600;
            color: #000;
        }

        .form-control 
        {
            border: 1px solid #000;
            background-color: #fff;
        }

        .form-control:focus 
        {
            box-shadow: none;
            border-color: #000;
        }

        .btn-primary 
        {
            background-color: #000;
            border-color: #000;
        }

        .btn-primary:hover 
        {
            background-color: #343a40;
        }

        .modal-content 
        {
            background-color: #fff;
        }

        .table 
        {
            background-color: #fff;
            border: 1px solid #000;
        }

        .table th, .table td 
        {
            border: 1px solid #000;
        }

        .table th 
        {
            background-color: #000;
            color: #fff;
        }
    </style>
</head>
<body>
<div class="container">
    <h1 class="mt-4">Inventory Management</h1>

    <form method="POST" action="" class="mt-4 mb-4">
        <div class="form-group">
            <input type="text" name="product_name" class="form-control" placeholder="Product Name" required>
        </div>
        <div class="form-group">
            <input type="number" name="quantity" class="form-control" placeholder="Quantity" required min="1">
        </div>
        <button type="submit" class="btn btn-primary">Purchase</button>
    </form>

    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel">Purchase Status</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="modalMessage"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-4">
        <table class="table">
            <thead>
            <tr>
                <th>Product Name</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Date Added</th>
            </tr>
            </thead>
            <tbody>
            <?php 
                $query = "SELECT * FROM product_management";
                $result = $connection->query($query);

                if ($result->num_rows > 0) 
                {
                    while ($row = $result->fetch_assoc()) 
                    {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['category']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['quantity']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['price']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['date_added']) . "</td>";
                        echo "</tr>";
                    }
                } 
                else 
                {
                    echo "<tr><td colspan='4' class='text-center'>No products available</td></tr>";
                }
            ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    $(document).ready(function() 
    {
        var message = "<?php echo addslashes($message); ?>";
        if (message) 
        {
            $('#modalMessage').text(message);
            $('#messageModal').modal('show'); 
        }
    });
</script>
</body>
</html>

<?php
$connection->close();
?>