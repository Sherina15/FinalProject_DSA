<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>
	<link rel = "stylesheet" href="home.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<body>

<header>
  	<a href="#" class="logo">Inventory Management System</a>
  		<nav>
		    <a href="#home" class="active">Home</a>
		    <a href="#about">About</a>
		    <a href="#services">Services</a>
		    <a href="#footer">Contact</a>
		    <a href="signin.php">Sign in</a>
    		
  		</nav>
</header>
			<section id="home">Home</section>
			<section id="about">About</section>
			<section id="services">Services</section>

			<script src="dashboard.js"></script>


	<div class="content-items">
		<image src>	
	</div>

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="footer-col">
					<h4>About Us</h4>
					<ul>
						<li><a href ="#">A. Mabini, 3006 Baliuag, Philippines, Baliuag, Philippines</a></li>
						<li><a href ="#">0956 964 8818</a></li>
					</ul>
				</div>
				<div class="footer-col">
					<h4>Follow us</h4>
					<div class="social-links">
						<a href ="https://www.facebook.com/profile.php?id=100076236223707"><i class="fab fa-facebook-f"></i></a>
					</div>
				</div>
			</div>
		</div>
</footer>

<footer class="footer" id="footer"> 
	<div class="container">
		<div class="row">
		</div>
	</div>
</footer>
	<div class="footerBotton">
		<p>Copyright &copy;2024; Designed by <span class="designer">Pelko</span></p>
	</div>

</body>
</html>