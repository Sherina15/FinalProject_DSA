<?php 
session_start();
if (!isset($_SESSION['username'])) 
{
    header('Location: login.php'); 
    exit();
}

$username = htmlspecialchars($_SESSION['username']);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "details_inventory_management";

$connection = new mysqli($servername, $username, $password, $dbname);

if ($connection->connect_error) 
{
    die("Connection Failed: " . $connection->connect_error);
}

$purchase_query = "SELECT id, product_name, category, purchased_quantity AS quantity, price, purchase_date FROM purchase_management ORDER BY purchase_date DESC";
$purchase_result = $connection->query($purchase_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
    <style>
        body 
        {
            background-color: #f8f9fa; 
        }
        .container 
        {
            margin-top: 50px; 
        }
        .table-responsive 
        {
            max-height: 400px; 
            overflow-y: scroll; 
        }
        .card 
        {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
        }
        h1 
        {
            color: #343a40; 
        }
    </style>
</head>
<body>
<div class="container">

    <div class="card">
        <div class="card-body">
            <h1 class="mt-4">Purchase Management</h1>

            <div class="table-responsive mt-4">
                <table class="table table-striped table-bordered" id="purchaseTable">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Category</th>
                            <th scope="col">Purchased Quantity</th>
                            <th scope="col">Price</th>
                            <th scope="col">Purchased Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($purchase_result->num_rows > 0) 
                        {
                            while ($row = $purchase_result->fetch_assoc()) 
                            {
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                                    <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['category']); ?></td>
                                    <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                                    <td><?php echo number_format($row['price'], 2); ?></td>
                                    <td><?php echo htmlspecialchars($row['purchase_date']); ?></td>
                                </tr>
                                <?php
                            }
                        } 
                        else 
                        {
                            echo '<tr><td colspan="6" class="text-center">No purchase records found</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready(function() 
{
    $('#purchaseTable').DataTable({
        "order": [], 
    });
});
</script>

</body>
</html>

<?php
$connection->close();
?>