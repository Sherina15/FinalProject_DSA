<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "details_inventory_management";

$connection = new mysqli($servername, $username, $password, $dbname);

if ($connection->connect_error) 
{
    die("Connection Failed: " . $connection->connect_error);
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    $full_name = $_POST['full_name']; 
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); 
    
    $check_query = "SELECT * FROM account_management WHERE username = '$username' OR email = '$email'";
    $check_result = $connection->query($check_query);

    if ($check_result->num_rows > 0) 
    {
        $error_message = "Username or email already exists.";
    } 
    else 
    {     
        $insert_query = "INSERT INTO account_management (full_name, username, email, password) VALUES ('$full_name', '$username', '$email', '$hashed_password')";

        if ($connection->query($insert_query) === TRUE) 
        {
            $success_message = "Registration successful! You can now log in.";
        }
        else 
        {
            $error_message = "Error: " . $insert_query . "<br>" . $connection->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css"> 
    <style>
        body 
        {
            background-color: #f8f9fa; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0;
        }
        .card 
        {
            border-radius: 15px; 
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); 
            border: none; 
            width: 90%; 
            max-width: 400px; 
        }
        .logo 
        {
            display: block;
            margin: 0 auto 20px; 
            max-width: 120px;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="card-header text-center">
            <img src="dog_logo.png" alt="logo" class="logo">
            <h3 class="mt-2">Registration</h3>
        </div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" name="full_name" class="form-control" placeholder="Enter your full name" required pattern ="\S.*">
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Choose a username" required pattern ="\S.*">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" class="form-control" placeholder="Enter your email" required pattern ="\S.*">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Create a password" required pattern ="\S.*">
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Register</button>
                </form>
                <div class="text-center mt-3">
                    <p>Already have an account? <a href="signin.php">Sign in</a></p>
                </div>
        </div>
    </div>

    <div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel">Message</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
        $(document).ready(function () 
        {
            <?php if (!empty($error_message) || !empty($success_message)): ?>
                $('#messageModal').modal('show');
            <?php endif; ?>
        });
    </script>
</body>
</html>
